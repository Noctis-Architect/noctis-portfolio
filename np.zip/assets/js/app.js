/* ==========================================================================
   Noctis Architect — page behaviour
   • language switch (soft dissolve, fonts pre-loaded, scroll position kept)
   • theme switch (circular reveal via View Transitions, graceful fallback)
   • curtain transition between the real pages
   • scroll reveals, header state, card tilt, project filter
   ========================================================================== */
(function () {
  'use strict';

  var D = document, H = D.documentElement, B = D.body;
  var $ = function (s, r) { return (r || D).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || D).querySelectorAll(s)); };
  var I = window.NX_I18N || { en: {}, fa: {} };
  var Scene = window.NXScene || { init: function () {}, start: function () {}, measure: function () {}, zone: function () {}, theme: function () {}, dir: function () {}, dive: function () {} };
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  var page = B.getAttribute('data-page') || 'home';
  var lang = H.lang === 'fa' ? 'fa' : 'en';
  var theme = H.getAttribute('data-theme') === 'light' ? 'light' : 'dark';

  var EASE_IO = 'cubic-bezier(.65,0,.35,1)';
  var EASE_OUT = 'cubic-bezier(.16,1,.3,1)';
  var EASE_CURTAIN = 'cubic-bezier(.76,0,.24,1)';

  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var store = function (k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; };
  var t = function (k) { var d = I[lang]; return (d && d[k] !== undefined) ? d[k] : (I.en[k] || ''); };
  var finished = function (a) { return a.finished.catch(function () {}); };

  /* the 3D cluster must sit in the empty space next to / under the first block of text (measured, not guessed) */
  function measure() {
    var el = $('.ht') || $('.ib');
    if (el) {
      var r = el.getBoundingClientRect(), top = r.bottom + (window.pageYOffset || 0) + 14;
      var nav = $('.mnav'), navShown = nav && getComputedStyle(nav).display !== 'none';
      var box = el.closest('.hero, .intro'), end = box ? box.getBoundingClientRect().bottom + (window.pageYOffset || 0) - 10 : 1e9;
      Scene.zone(top, Math.min(end, (navShown ? nav.getBoundingClientRect().top : window.innerHeight - 16) - 10));
    }
    Scene.measure();
  }

  /* ------------------------------------------------------------ headings: word masks */
  function splitHeading(el) {
    el.setAttribute('aria-label', el.textContent.replace(/\s+/g, ' ').trim());
    var j = 0;
    (function walk(n) {
      Array.prototype.slice.call(n.childNodes).forEach(function (c) {
        if (c.nodeType === 3) {
          var f = D.createDocumentFragment();
          c.textContent.split(/(\s+)/).forEach(function (s) {
            if (!s) return;
            if (!s.trim()) { f.appendChild(D.createTextNode(s)); return; }
            var o = D.createElement('span'), i = D.createElement('span');
            o.className = 'w'; o.setAttribute('aria-hidden', 'true');
            i.textContent = s; i.style.setProperty('--j', j++);
            o.appendChild(i); f.appendChild(o);
          });
          c.parentNode.replaceChild(f, c);
        } else if (c.nodeType === 1) walk(c);
      });
    })(el);
  }

  /* ------------------------------------------------------------ translations */
  function applyText(first) {
    var skipSwap = first && lang === 'en';              // English is already in the markup
    $$('[data-i]').forEach(function (el) {
      if (!skipSwap) { var v = t(el.getAttribute('data-i')); if (v) el.innerHTML = v; }
      if (el.classList.contains('hd')) splitHeading(el);
    });
    $$('[data-i-aria]').forEach(function (el) { el.setAttribute('aria-label', t(el.getAttribute('data-i-aria'))); });
    if (page !== 'project') {                            // project pages carry their own title/description
      D.title = t('t_' + page) || D.title;
      var desc = t('d_' + page);
      [['meta[name="description"]', 'content'], ['meta[property="og:title"]', 'content'], ['meta[property="og:description"]', 'content']].forEach(function (p, n) {
        var m = $(p[0]); if (!m) return;
        var v = n === 1 ? D.title : desc;
        if (v) m.setAttribute(p[1], v);
      });
    }
    var lb = $('#lg span'); if (lb) lb.textContent = lang === 'fa' ? 'EN' : 'FA';
  }

  function commitLang(next) {
    lang = next; store('nx-lang', lang);
    H.lang = lang; H.dir = lang === 'fa' ? 'rtl' : 'ltr';
    applyText(false);
    Scene.dir(lang === 'fa');
  }

  /* Download the faces we are about to need so the swap never flashes a fallback font */
  function ensureFonts(l) {
    if (!D.fonts || !D.fonts.load) return Promise.resolve();
    var faces = l === 'fa'
      ? ['300 1em Vazirmatn', '400 1em Vazirmatn', '800 1em Vazirmatn']
      : ['400 1em Inter', '600 1em Inter', '400 1em "Instrument Serif"', 'italic 400 1em "Instrument Serif"'];
    var sample = l === 'fa' ? 'آبپچژگکی۰۱۲۳' : 'Aa';
    return Promise.race([
      Promise.all(faces.map(function (f) { return D.fonts.load(f, sample); })),
      sleep(1800)
    ]).catch(function () {});
  }

  /* ------------------------------------------------------------ language switch */
  var busy = false;

  function visibleLeaves() {
    var vh = window.innerHeight, list = [];
    $$('[data-i]').forEach(function (el) {
      var r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0 || r.bottom < 0 || r.top > vh) return;
      list.push({ el: el, top: r.top });
    });
    list.sort(function (a, b) { return a.top - b.top; });
    return list.map(function (x) { return x.el; });
  }
  function chrome() { return [$('.hdr'), $('main'), $('footer'), $('.mnav')].filter(Boolean); }

  function dissolveOut() {
    var anims = chrome().map(function (el) {
      return el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 460, easing: EASE_IO, fill: 'forwards' });
    });
    visibleLeaves().forEach(function (el, i) {
      anims.push(el.animate(
        [{ opacity: 1, filter: 'blur(0px)', transform: 'translateY(0)' }, { opacity: 0, filter: 'blur(10px)', transform: 'translateY(-10px)' }],
        { duration: 400, delay: Math.min(i * 14, 180), easing: EASE_IO, fill: 'forwards' }));
    });
    return anims;
  }
  function dissolveIn() {
    var anims = chrome().map(function (el) {
      return el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 900, easing: 'cubic-bezier(.33,0,.2,1)', fill: 'backwards' });
    });
    visibleLeaves().forEach(function (el, i) {
      anims.push(el.animate(
        [{ opacity: 0, filter: 'blur(14px)', transform: 'translateY(16px)' }, { opacity: 1, filter: 'blur(0px)', transform: 'translateY(0)' }],
        { duration: 1100, delay: Math.min(i * 40, 640), easing: EASE_OUT, fill: 'backwards' }));
    });
    return anims;
  }

  /* keep whatever the reader was looking at in the same place after the layout flips */
  function anchorCapture() {
    if ((window.pageYOffset || 0) < 12) return null;
    var y = window.innerHeight * 0.38, els = $$('main [data-anchor]');
    for (var i = 0; i < els.length; i++) {
      var r = els[i].getBoundingClientRect();
      if (r.top <= y && r.bottom > y) return { el: els[i], f: (y - r.top) / Math.max(1, r.height), y: y };
    }
    return null;
  }
  function anchorRestore(a) {
    if (!a) return;
    var r = a.el.getBoundingClientRect(), d = r.top + a.f * r.height - a.y;
    if (Math.abs(d) > 1) window.scrollBy(0, d);
  }

  async function switchLang() {
    if (busy || navigating) return;
    busy = true;
    var next = lang === 'fa' ? 'en' : 'fa';
    var fonts = ensureFonts(next);
    var btn = $('#lg');

    if (reduce.matches) {
      await fonts; commitLang(next); measure(); busy = false; return;
    }

    if (btn) btn.classList.add('sw');
    var outs = dissolveOut();
    await Promise.all(outs.map(finished).concat([fonts]));

    var anchor = anchorCapture();
    commitLang(next);                         // text, lang, dir, title, 3D mirror
    if (btn) btn.classList.remove('sw');
    anchorRestore(anchor);
    measure();

    var ins = dissolveIn();                   // start the fade-in first …
    outs.forEach(function (a) { a.cancel(); });   // … then drop the old hold, in the same task → no frame in between
    await Promise.all(ins.map(finished));
    busy = false;
  }

  /* ------------------------------------------------------------ theme switch
     the old theme is painted over the page and then dissolves away from the toggle,
     so the new theme is already in place underneath — nothing ever goes blank.
     the content settles back from a soft zoom/blur and a thin accent ring rides the edge. */
  var theming = false;
  function applyTheme(next) {
    theme = next; H.setAttribute('data-theme', next); store('nx-theme', next);
    var m = $('meta[name="theme-color"]'); if (m) m.setAttribute('content', next === 'light' ? '#f5f4ef' : '#0d0e11');
    Scene.theme();
  }
  function onTheme() {
    if (theming) return;
    var next = theme === 'dark' ? 'light' : 'dark';
    if (reduce.matches) { applyTheme(next); return; }

    theming = true;
    var r = this.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    var rad = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y)) * 1.12;

    var ov = D.createElement('div');
    ov.className = 'tsw';
    ov.style.background = theme === 'light' ? '#f5f4ef' : '#0d0e11';
    ov.style.setProperty('--tx', x + 'px');
    ov.style.setProperty('--ty', y + 'px');
    ov.style.setProperty('--tw', '0px');
    B.appendChild(ov);

    var ring = D.createElement('div');
    ring.className = 'tsr';
    ring.style.setProperty('--tx', x + 'px');
    ring.style.setProperty('--ty', y + 'px');
    ring.style.setProperty('--td', (rad * 2) + 'px');
    B.appendChild(ring);

    applyTheme(next);

    [$('.hdr'), $('main'), $('footer'), $('.mnav')].filter(Boolean).forEach(function (el) {
      el.animate(
        [{ opacity: .45, transform: 'scale(1.018)', filter: 'blur(6px)' }, { opacity: 1, transform: 'scale(1)', filter: 'blur(0px)' }],
        { duration: 900, easing: 'cubic-bezier(.16,1,.3,1)', fill: 'backwards' });
    });

    requestAnimationFrame(function () {
      ov.style.transition = '--tw 900ms cubic-bezier(.65,0,.35,1)';
      ov.style.setProperty('--tw', rad + 'px');
      ring.animate(
        [{ transform: 'translate(-50%,-50%) scale(.2)', opacity: .9 }, { transform: 'translate(-50%,-50%) scale(1)', opacity: 0 }],
        { duration: 900, easing: 'cubic-bezier(.65,0,.35,1)', fill: 'forwards' });
    });
    setTimeout(function () { ov.remove(); ring.remove(); theming = false; }, 980);
  }

  /* ------------------------------------------------------------ portal between pages
     leaving : the camera dives INTO the wireframe while the page rushes past, then the
               curtain closes over it — no words, no labels
     arriving: the camera pulls back OUT of the next page's solid and the curtain lifts   */
  var CV = $('#cv');
  var navigating = false, prefetched = {};

  function prefetch(url) {
    if (prefetched[url]) return; prefetched[url] = 1;
    var l = D.createElement('link'); l.rel = 'prefetch'; l.href = url; D.head.appendChild(l);
  }
  function resetPortal() {
    navigating = false;
    [CV].concat(chrome()).forEach(function (el) { if (el) el.getAnimations().forEach(function (a) { a.cancel(); }); });
    var m = $('main'); if (m) { m.style.transformOrigin = ''; m.getAnimations().forEach(function (a) { a.cancel(); }); }
    if (CV) CV.classList.remove('on');
    H.classList.remove('nx');
    Scene.dive(0, 0);
  }

  function leavePage(url) {
    if (navigating || busy) return;
    navigating = true;
    try { sessionStorage.setItem('nx-nav', '1'); } catch (e) {}
    prefetch(url);

    var main = $('main'), y = window.innerHeight * 0.5 - main.getBoundingClientRect().top;
    Scene.dive(1, 900, 'in');                                                     // fly into the wireframe
    main.style.transformOrigin = '50% ' + y + 'px';
    main.animate([{ transform: 'scale(1)', opacity: 1, filter: 'blur(0px)' }, { transform: 'scale(1.18)', opacity: 0, filter: 'blur(14px)' }],
      { duration: 720, easing: 'cubic-bezier(.5,0,.9,.35)', fill: 'forwards' });         // the page rushes past the camera
    /* header, mobile nav and footer stay put — only the page body travels */
    CV.classList.add('on');
    CV.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 520, delay: 340, easing: EASE_IO, fill: 'forwards' });   // the wireframe melts into the page colour

    setTimeout(function () { window.location.href = url; }, 880);
    setTimeout(function () { if (navigating) resetPortal(); }, 5000);               // never leave anyone stuck inside the tunnel
  }

  async function arrive() {
    var main = $('main');
    Scene.dive(0, 1500, 'out');                                                      // pull back out of the new solid
    main.animate([{ transform: 'scale(1.04)', opacity: 0, filter: 'blur(8px)' }, { transform: 'scale(1)', opacity: 1, filter: 'blur(0px)' }],
      { duration: 820, easing: EASE_OUT, fill: 'backwards' });
    /* the chrome never fades — it is already in place on the new page */
    CV.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 620, delay: 60, easing: EASE_IO, fill: 'forwards' });
    await sleep(240);
    startReveal();                                                                   // the page builds itself as the tunnel clears
    await sleep(700);
    CV.getAnimations().forEach(function (a) { a.cancel(); });
    CV.classList.remove('on');
    H.classList.remove('nx');
    navigating = false;
  }

  /* ------------------------------------------------------------ scroll reveals */
  var io = null;
  if ('IntersectionObserver' in window) {
    io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
  }
  function startReveal() {
    H.classList.add('ready');
    $$('.r, .hd').forEach(function (el) { if (io) io.observe(el); else el.classList.add('in'); });
  }

  /* ------------------------------------------------------------ header + progress */
  var hdr = $('.hdr'), pg = $('#pg'), ticking = false;
  function onScroll() {
    if (ticking) return; ticking = true;
    requestAnimationFrame(function () {
      ticking = false;
      var y = window.pageYOffset || 0, m = H.scrollHeight - window.innerHeight;
      pg.style.transform = 'scaleX(' + (m > 0 ? Math.min(1, y / m) : 0) + ')';
      hdr.classList.toggle('sc', y > 24);
    });
  }

  /* ------------------------------------------------------------ card tilt */
  var tiltEl = null, tiltRaf = 0;
  function tiltReset(c) { c.classList.remove('tilting'); ['--rx', '--ry', '--ty'].forEach(function (p) { c.style.removeProperty(p); }); }
  function onPointerMove(e) {
    if (e.pointerType === 'touch' || reduce.matches) return;
    var c = e.target.closest && e.target.closest('.card');
    if (!c) { if (tiltEl) { tiltReset(tiltEl); tiltEl = null; } return; }
    if (tiltEl && tiltEl !== c) tiltReset(tiltEl);
    tiltEl = c;
    var r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
    cancelAnimationFrame(tiltRaf);
    tiltRaf = requestAnimationFrame(function () {
      c.classList.add('tilting');
      c.style.setProperty('--ry', ((x - 0.5) * 9).toFixed(2) + 'deg');
      c.style.setProperty('--rx', (-(y - 0.5) * 9).toFixed(2) + 'deg');
      c.style.setProperty('--ty', '-6px');
      c.style.setProperty('--mx', (x * 100).toFixed(1) + '%');
      c.style.setProperty('--my', (y * 100).toFixed(1) + '%');
    });
  }
  function onPointerOut(e) {
    var c = e.target.closest && e.target.closest('.card');
    if (c && !c.contains(e.relatedTarget)) { cancelAnimationFrame(tiltRaf); tiltReset(c); if (tiltEl === c) tiltEl = null; }
  }

  /* ------------------------------------------------------------ nav pill
     the white pill is drawn from the side the pointer came from, so the
     header already shows the destination while the page is still leaving */
  function navFill(a) {
    var nav = a.closest('.nv, .mnav');
    if (!nav) return;
    var links = $$('a', nav), from = links.findIndex(function (x) { return x.hasAttribute('aria-current'); });
    var to = links.indexOf(a);
    if (to < 0) return;
    links.forEach(function (x) { x.classList.remove('nx-go', 'nx-on', 'nx-rev'); });
    if (from >= 0 && to < from) a.classList.add('nx-rev');
    a.classList.add('nx-go');
    void a.offsetWidth;
    a.classList.add('nx-on');
  }

  /* ------------------------------------------------------------ project filter */
  function initFilter() {
    var chips = $$('.chips button'); if (!chips.length) return;
    chips.forEach(function (b) {
      b.addEventListener('click', function () {
        var f = b.getAttribute('data-f');
        chips.forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
        $$('.rw').forEach(function (r) { r.classList.toggle('off', f !== 'all' && r.getAttribute('data-c') !== f); });
        $$('.grp').forEach(function (g) { g.classList.toggle('off', $$('.rw:not(.off)', g).length === 0); });
        setTimeout(measure, 750);
      });
    });
  }

  /* ------------------------------------------------------------ boot */
  function bind() {
    $('#lg').addEventListener('click', switchLang);
    $('#lg').addEventListener('pointerenter', function () { ensureFonts(lang === 'fa' ? 'en' : 'fa'); });
    $('#th').addEventListener('click', onTheme);
    window.addEventListener('scroll', onScroll, { passive: true });
    D.addEventListener('pointermove', onPointerMove, { passive: true });
    D.addEventListener('pointerout', onPointerOut);

    D.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[data-p]');
      if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var key = a.getAttribute('data-p');
      if (key === page) { e.preventDefault(); window.scrollTo({ top: 0, behavior: reduce.matches ? 'auto' : 'smooth' }); return; }
      if (reduce.matches) return;                       // plain navigation
      e.preventDefault();
      navFill(a);
      leavePage(a.href);
    });
    function warm(e) { var a = e.target.closest && e.target.closest('a[data-p]'); if (a && a.getAttribute('data-p') !== page) prefetch(a.href); }
    D.addEventListener('pointerover', warm, { passive: true });
    D.addEventListener('focusin', warm);

    window.addEventListener('pageshow', function (e) { if (e.persisted) resetPortal(); });    // back button / bfcache
    if (window.ResizeObserver) new ResizeObserver(measure).observe(B);
    initFilter();
  }

  function boot() {
    applyText(true);
    var nx = H.classList.contains('nx') && !reduce.matches && !!CV;                   // arriving through the portal
    Scene.init({ canvas: $('#gl'), page: page, dive: nx ? 1 : 0 });
    Scene.dir(lang === 'fa', true);
    bind(); onScroll();

    Promise.race([ensureFonts(lang), sleep(1300)]).then(function () {
      measure(); Scene.start();
      if (nx) arrive();
      else { H.classList.remove('nx'); startReveal(); }
    });

    // quietly warm up the other language's fonts so the first switch is instant
    var idle = window.requestIdleCallback || function (f) { setTimeout(f, 1800); };
    idle(function () { ensureFonts(lang === 'fa' ? 'en' : 'fa'); });
  }

  boot();
})();
